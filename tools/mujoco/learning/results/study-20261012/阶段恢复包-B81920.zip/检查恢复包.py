"""只读核对迁移后的研究包，并实际重跑两个既有开发基线；不启动续训。"""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def require(value, message):
    if not value:
        raise RuntimeError(message)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--route", choices=("abc", "reference"))
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    inventory = read(root / "恢复包清单.json")
    for relative, expected in inventory["files"].items():
        require(hashlib.sha256((root / relative).read_bytes()).hexdigest() == expected,
                "包内文件损坏：" + relative)
    if args.route is None:
        for route in ("abc", "reference"):
            subprocess.run([sys.executable, str(Path(__file__).resolve()), "--route", route], check=True)
        return
    snapshot = root / "snapshots" / args.route
    sys.path.insert(0, str(snapshot / "tools/mujoco/learning"))
    import numpy as np
    from WbrLearningEnv import verify_snapshot, experiment_identity
    from EvaluateWbrStudy import load_cases, run_case
    from StudyWbrPolicy import StudyPolicy
    manifest = verify_snapshot(snapshot)
    identity = experiment_identity(manifest)
    expected = inventory["snapshots"][args.route]
    require(identity == expected["experiment_identity"], "实验身份不符")
    require(manifest["library_sha256"] == expected["library_sha256"], "动态库身份不符")
    cases = load_cases(snapshot / "tools/mujoco/learning/cases/study-20261012/development.json")
    details = {}
    if args.route == "abc":
        import torch
        from stable_baselines3 import PPO
        torch.set_num_threads(1)
        checkpoint = root / "recovery/B-symmetric-41"
        contract = read(checkpoint / "policy.json")
        for name, key in (("checkpoint.zip", "checkpoint_sha256"), ("policy.npz", "policy_sha256")):
            require(hashlib.sha256((checkpoint / name).read_bytes()).hexdigest() == contract[key],
                    "训练保存点哈希不符")
        require(contract["experiment_identity"] == identity, "训练环境身份不符")
        require(contract["library_sha256"] == manifest["library_sha256"], "训练动态库不符")
        model = PPO.load(checkpoint / "checkpoint.zip", device="cpu")
        require(model.num_timesteps == contract["training_steps"], "训练步数不符")
        require(model.action_space.shape == (3,), "对称动作维数不符")
        optimizer = model.policy.optimizer.state_dict()["state"]
        require(bool(optimizer), "缺少优化器保存状态")
        policy = StudyPolicy(checkpoint)
        observations = np.random.default_rng(98012).uniform(-1, 1, (64, 93)).astype(np.float32)
        tensor_actions, _ = model.predict(observations, deterministic=True)
        exported = np.stack([policy.predict(row) for row in observations])
        error = float(np.max(np.abs(tensor_actions - exported)))
        require(error < 2e-6, "导出权重与训练网络推理不符")
        details = dict(steps=model.num_timesteps, optimizer_states=len(optimizer), export_max_abs_error=error)
        config = contract["env_config"]
    else:
        from SearchWbrLinear import state_hash, validate_rows, reference_score
        from BuildWbrStudyCases import canonical_bytes
        state = read(root / "recovery/D-reference-41/search-state.json")
        require(state["state_sha256"] == state_hash(state), "搜索状态哈希不符")
        binding = state["binding"]
        require(binding["experiment_identity"] == identity, "搜索环境身份不符")
        require(binding["library_sha256"] == manifest["library_sha256"], "搜索动态库不符")
        require(binding["scenarios_sha256"] == cases["cases_sha256"], "开发场景不符")
        for name, expected_hash in binding["source_hashes"].items():
            require(hashlib.sha256((snapshot / "tools/mujoco/learning" / name).read_bytes()).hexdigest()
                    == expected_hash, "搜索源码身份不符")
        validate_rows(state["baseline"], cases["cases"])
        for candidate in state["population"]:
            validate_rows(candidate["results"], cases["cases"])
        for rows in state["cache"].values():
            validate_rows(rows, cases["cases"])
        for item in state["evaluations"]:
            rows = state["cache"][canonical_bytes(item["coefficients"]).decode()]
            score, report = reference_score(state["baseline"], rows)
            require(score == item["score"] and report["checks"] == item["checks"], "搜索评分无法复算")
        generator = np.random.default_rng()
        generator.bit_generator.state = state["rng_state"]
        require(generator.bit_generator.state == state["rng_state"], "搜索随机状态无法恢复")
        details = dict(generation=state["generation"], evaluations=len(state["evaluations"]),
                       cached_candidates=len(state["cache"]), rng_state_restored=True)
        config = binding["env_config"]
    actual = run_case(cases["cases"][0], None, config)
    expected_baseline = read(root / "verification" / (args.route + "-baseline.json"))
    require(actual == expected_baseline, "迁移目录后基线未能逐字段复现")
    print(json.dumps(dict(route=args.route, status="passed", experiment_identity=identity,
                          baseline_case=actual["id"], baseline_exact=True, **details), ensure_ascii=False), flush=True)

if __name__ == "__main__":
    main()

"""检查迁移目录中的E方案真实模型和冻结环境；不启动续训。"""
import hashlib
import json
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
read = lambda path: json.loads(path.read_text(encoding="utf-8"))
digest = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
def require(value, message):
    if not value:
        raise RuntimeError(message)

inventory = read(root / "恢复包清单.json")
for relative,expected in inventory["files"].items():
    require(digest(root / relative) == expected,"包内文件不符："+relative)
sys.path.insert(0,str(root / "snapshot/tools/mujoco/learning"))
import numpy as np
import torch
from stable_baselines3 import PPO
from WbrLearningEnv import verify_snapshot,experiment_identity
from StudyWbrPolicy import StudyPolicy
from TrainWbrAligned import validate_training_bank
from EvaluateWbrStudy import load_cases,run_case

manifest = verify_snapshot()
require(experiment_identity(manifest) == inventory["experiment_identity"],"迁移后物理身份不符")
learning = root / "snapshot/tools/mujoco/learning"
registration_path = learning / "results/study-20261012/对齐评分参考策略训练登记.json"
registration = read(registration_path)
bank_path = learning / "results/study-20261012/aligned-training-baseline/training-bank.json"
validate_training_bank(registration,registration_path,bank_path,manifest)
checkpoint = root / "recovery/E-aligned-41"
contract = read(checkpoint / "policy.json")
require(digest(checkpoint / "checkpoint.zip") == contract["checkpoint_sha256"] and digest(checkpoint / "policy.npz") == contract["policy_sha256"],"训练保存点内容不符")
torch.set_num_threads(1)
model = PPO.load(checkpoint / "checkpoint.zip",device="cpu")
require(model.num_timesteps == inventory["steps"] == contract["training_steps"],"迁移模型步数不符")
optimizer = model.policy.optimizer.state_dict()["state"]
require(bool(optimizer),"训练保存点缺少优化器")
observations = np.random.default_rng(63419).normal(0,.5,(128,93)).astype(np.float32)
expected,_ = model.predict(observations,deterministic=True)
policy = StudyPolicy(checkpoint)
actual = np.asarray([policy.predict(row) for row in observations])
error = float(np.max(np.abs(actual-expected)))
require(error < 2e-5,"迁移模型导出推理不符")
cases = load_cases(learning / "cases/study-20261012/development.json")
result = run_case(cases["cases"][0],None,contract["env_config"])
baseline = read(root / "evidence/baselines/development/summary.json")["baseline_results"][0].copy()
require(baseline.pop("controller") == "baseline" and result == baseline,"迁移后原控制基线无法逐字段复现")
record = dict(schema=1,status="passed",steps=model.num_timesteps,optimizer_states=len(optimizer),
    export_max_abs_error=error,baseline_case=result["id"],baseline_all_fields_exact=True,
    experiment_identity=experiment_identity(manifest),library_sha256=manifest["library_sha256"],
    bank_admission_revalidated=True,boundary="同机换目录的真实模型载入、导出推理和原控制基线重放；未在另一电脑验证，未启动续训或最终集。")
(root / "恢复核验结果.json").write_bytes((json.dumps(record,ensure_ascii=False,indent=2)+"\n").encode("utf-8"))
print(json.dumps(record,ensure_ascii=False))

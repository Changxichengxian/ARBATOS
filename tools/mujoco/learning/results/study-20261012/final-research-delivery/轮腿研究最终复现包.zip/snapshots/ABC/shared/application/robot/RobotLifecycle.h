/*
 * SPDX-FileCopyrightText: 2026 陈轩 <2811158416@qq.com>
 * SPDX-License-Identifier: Apache-2.0
 */

#ifndef ROBOT_LIFECYCLE_H
#define ROBOT_LIFECYCLE_H

#include <stdint.h>

#define ROBOT_LIFECYCLE_UPDATE_TIMEOUT_MS 20u

typedef enum
{
    ROBOT_LIFECYCLE_BOOT = 0u,
    ROBOT_LIFECYCLE_SAFE,
    ROBOT_LIFECYCLE_ACTIVE,
    ROBOT_LIFECYCLE_FAULT,
} RobotLifecycleState;

typedef enum
{
    ROBOT_LIFECYCLE_REASON_BOOT = 0u,
    ROBOT_LIFECYCLE_REASON_NONE,
    ROBOT_LIFECYCLE_REASON_MANUAL_OFFLINE,
    ROBOT_LIFECYCLE_REASON_MANUAL_SAFE_SWITCH,
    /* 数值 4 曾用于可恢复故障锁存；保留后续诊断编号，避免旧日志错译。 */
    ROBOT_LIFECYCLE_REASON_FATAL_FAULT = 5u,
    ROBOT_LIFECYCLE_REASON_STARTUP_SAFE_REQUIRED = 6u,
    ROBOT_LIFECYCLE_REASON_UPDATE_STALE = 7u,
    ROBOT_LIFECYCLE_REASON_MAINTENANCE = 8u,
} RobotLifecycleReason;

typedef struct
{
    RobotLifecycleState state;
    RobotLifecycleState prev_state;
    RobotLifecycleReason reason;
    uint32_t enter_tick;
    uint32_t transition_count;
    uint8_t output_allowed;
    uint8_t manual_online;
    uint8_t manual_safe;
    uint8_t fault_latched;
    uint8_t startup_safe_seen;
    uint8_t maintenance_latched;
    uint32_t update_tick;
    uint32_t manual_semantics_seq;
    uint32_t manual_authority_seq;
} RobotLifecycleSnapshot;

void RobotLifecycleInit(void);
void RobotLifecycleUpdate(void);
RobotLifecycleState RobotLifecycleCurrent(void);
uint8_t RobotLifecycleOutputAllowed(void);
uint8_t RobotLifecycleGetSnapshot(RobotLifecycleSnapshot *out);
void RobotLifecycleEnterFatalFault(void);
/* 手动校准停机；本次启动内没有解除接口。 */
uint8_t RobotLifecycleEnterMaintenance(void);
uint8_t RobotLifecycleFaultLatched(void);
const char *RobotLifecycleName(RobotLifecycleState state);

#endif

/*
 * SPDX-FileCopyrightText: 2026 陈轩 <2811158416@qq.com>
 * SPDX-License-Identifier: Apache-2.0
 *
 * First published in this repository: 2026-04-06
 * Use of this file is governed by the LICENSE file in the repository root.
 */

#ifndef LOWCMD_H
#define LOWCMD_H

#include <stddef.h>
#include <stdint.h>

#include "ControlOutputPermit.h"
#if defined(__has_include)
#if __has_include("RobotTargetConfig.h")
/* LowCmd.c 也必须看到车型生成结果，保证 Servo 车型各编译单元的槽位数一致。 */
#include "RobotTargetConfig.h"
#endif
#endif
#include "RobotTaskBuildConfig.h"
#include "Types.h"

#define LOWCMD_DEFAULT_TIMEOUT_MS 100u
#define LOWCMD_PRIORITY_HOLD_MS 100u

typedef enum
{
    LOWCMD_WRITER_NONE = 0u,
    LOWCMD_WRITER_CONTROL = 10u,
    LOWCMD_WRITER_MANUAL = 20u,
    LOWCMD_WRITER_HOST = 30u,
    LOWCMD_WRITER_SAFETY = 240u,
    LOWCMD_WRITER_MAINTENANCE = 241u,
    LOWCMD_WRITER_FAULT = 255u,
} LowCmdWriter;

typedef enum
{
    Motor0 = 0u,
    Motor1,
    Motor2,
    Motor3,
    Motor4,
    Motor5,
    Motor6,
    Motor7,
    Motor8,
    Motor9,
    Motor10,
    Motor11,
    Motor12,
    Motor13,
    Motor14,
    Motor15,
    Motor16,
    Motor17,
#if ROBOT_TASK_BUILD_SERVO
    Motor18,
    Motor19,
    Motor20,
    Motor21,
#endif
    MotorCount
} MotorId;

#if ROBOT_TASK_BUILD_SERVO
#define LOWCMD_SERVO_FIRST Motor18
#define LOWCMD_SERVO_COUNT 4u
#endif

typedef enum
{
    MotorModeNone = 0u,
    MotorModeDisable,
    MotorModeDamping,
    MotorModeCurrent, // 兼容原始驱动给定；RM 电压/电流量纲由轴的 control_mode 决定
    MotorModeStateTorque, // q/dq/kp/kd/tau, transport-independent
    MotorModePosVel,
    MotorModeSpeed,
    MotorModeForcePos,
    MotorModeCount,
} MotorMode;

typedef enum
{
    MotorDriveStateUnknown = 0u,
    MotorDriveStateOffline,
    MotorDriveStateDisabled,
    MotorDriveStateReady,
    MotorDriveStateEnabled,
    MotorDriveStateFault,
} MotorDriveState;

typedef enum
{
    MotorCmdCapCurrent = 1u << 0,
    MotorCmdCapStateTorque = 1u << 1,
    MotorCmdCapPosVel = 1u << 2,
    MotorCmdCapSpeed = 1u << 3,
    MotorCmdCapForcePos = 1u << 4,
    MotorCmdCapFeedback = 1u << 5,
} MotorCmdCap;

typedef enum
{
    MotorTransportNone = 0u,
    MotorTransportCAN,
    MotorTransportRS485,
    MotorTransportPWM,
    MotorTransportUART,
} MotorTransport;

typedef enum
{
    MotorAppliedFlagLimited = 1u << 0,
    MotorAppliedFlagForceDisabled = 1u << 1,
    MotorAppliedFlagCmdExpired = 1u << 2,
    MotorAppliedFlagSkipped = 1u << 3,
} MotorAppliedFlag;

typedef struct
{
    uint32_t epoch;
    uint32_t seq;
} LowCmdVersion;

typedef struct
{
    uint8_t active;
    uint8_t mode; // MotorMode
    uint16_t timeoutMs;
    uint16_t writer;
    uint32_t seq;
    uint32_t tick;
    int16_t current;
    /* q 的物理含义由适配器定义；PWM Servo 槽使用 [-1,1] 归一化位置，0 为中点，不是 rad。 */
    fp32 q;
    fp32 dq;
    fp32 kp;
    fp32 kd;
    fp32 tau;
    uint32_t seqEpoch;
} MotorCmd;

/* 发送完成可能晚于命令缓存更新，只保存核对物理回执所需的不可变身份。 */
typedef struct
{
    uint32_t cmdSeq;
    uint32_t cmdTick;
    int16_t current;
    uint16_t writer;
    uint8_t active;
    uint8_t mode;
    uint8_t reserved0;
    uint8_t reserved1;
    uint32_t cmdSeqEpoch;
} MotorTxIdentity;

static inline void MotorTxIdentityFromCmd(MotorTxIdentity *identity,
                                          const MotorCmd *cmd)
{
    if (identity == NULL || cmd == NULL)
    {
        return;
    }
    identity->cmdSeq = cmd->seq;
    identity->cmdTick = cmd->tick;
    identity->current = cmd->current;
    identity->writer = cmd->writer;
    identity->active = cmd->active;
    identity->mode = cmd->mode;
    identity->reserved0 = 0u;
    identity->reserved1 = 0u;
    identity->cmdSeqEpoch = cmd->seqEpoch;
}

static inline uint8_t MotorTxIdentityEqual(
    const MotorTxIdentity *left,
    const MotorTxIdentity *right)
{
    return (uint8_t)(left != NULL && right != NULL &&
                     left->cmdSeq == right->cmdSeq &&
                     left->cmdTick == right->cmdTick &&
                     left->current == right->current &&
                     left->writer == right->writer &&
                     left->active == right->active &&
                     left->mode == right->mode &&
                     left->cmdSeqEpoch == right->cmdSeqEpoch);
}

static inline uint8_t MotorTxIdentityMatchesCmd(
    const MotorTxIdentity *identity,
    const MotorCmd *cmd)
{
    return (uint8_t)(identity != NULL &&
                     cmd != NULL &&
                     identity->cmdSeq == cmd->seq &&
                     identity->cmdTick == cmd->tick &&
                     identity->current == cmd->current &&
                     identity->writer == cmd->writer &&
                     identity->active == cmd->active &&
                     identity->mode == cmd->mode &&
                     identity->cmdSeqEpoch == cmd->seqEpoch);
}

/*
 * 发送层缓存只有仍指向当前发布代、且 writer 没被更高优先级禁写时才有效。
 * 调用者若要把检查和物理入队连成一个不可分割动作，必须在同一临界区内
 * 读取最新命令、禁写 owner、调用本函数并启动非阻塞发送。
 */
static inline uint8_t LowCmdSnapshotAuthorized(const MotorCmd *cached,
                                               const MotorCmd *latest,
                                               uint16_t inhibitWriter)
{
    uint16_t cachedWriter;

    if (cached == NULL || latest == NULL || latest->active == 0u ||
        cached->seq != latest->seq ||
        cached->seqEpoch != latest->seqEpoch ||
        cached->writer != latest->writer)
    {
        return 0u;
    }

    cachedWriter = (cached->writer == (uint16_t)LOWCMD_WRITER_NONE) ?
                       (uint16_t)LOWCMD_WRITER_CONTROL : cached->writer;
    if (inhibitWriter != (uint16_t)LOWCMD_WRITER_NONE && cachedWriter < inhibitWriter)
    {
        return 0u;
    }
    return 1u;
}

typedef struct
{
    uint8_t online;
    uint8_t bus;
    uint8_t rxDlc;
    uint8_t rxData0;   // raw first byte from the last feedback frame when available
    uint8_t transport; // MotorTransport
    uint8_t motorId;   // MIT feedback motor id when available
    uint8_t state;     // MIT feedback state when available
    uint8_t driveState; // MotorDriveState
    uint16_t rxId;
    uint16_t lastEcd;
    uint32_t rxCount;
    uint32_t lastRxTick;
    fp32 q;
    fp32 dq;
    fp32 tauEst;
    uint16_t ecd;
    int16_t speedRpm;
    int16_t current;
    uint8_t temperature;
} MotorState;

typedef struct
{
    uint8_t active;
    uint8_t mode;       // MotorMode
    uint8_t driveState; // MotorDriveState
    uint8_t flags;      // MotorAppliedFlag
    uint8_t bus;
    uint8_t transport; // MotorTransport
    uint8_t protocol;
    uint8_t reserved0;
    uint16_t txId;
    uint32_t tick;
    int16_t current;
    fp32 q;
    fp32 dq;
    fp32 kp;
    fp32 kd;
    fp32 tau;
} MotorApplied;

/*
 * queued 只表示硬件发送队列接受；valid 只在控制器确认帧完成总线发送后置位。
 * 它和 MotorApplied 分开：后者描述本轮换算结果，不能拿来证明命令已经上总线。
 */
typedef struct
{
    uint32_t cmdSeq;
    uint32_t cmdTick;
    uint32_t queuedTick;
    uint32_t completedTick;
    int16_t current;
    uint16_t writer;
    uint8_t valid;
    uint8_t queued;
    uint8_t mode;
    uint8_t reserved0;
    uint32_t cmdSeqEpoch;
} MotorTxReceipt;

static inline uint8_t MotorTxReceiptMatches(const MotorTxReceipt *receipt,
                                            uint32_t cmdSeq,
                                            uint32_t cmdSeqEpoch,
                                            uint32_t cmdTick,
                                            uint16_t writer,
                                            uint8_t mode,
                                            int16_t current)
{
    return (uint8_t)(receipt != NULL &&
                     receipt->valid != 0u &&
                     receipt->cmdSeq == cmdSeq &&
                     receipt->cmdSeqEpoch == cmdSeqEpoch &&
                     receipt->cmdTick == cmdTick &&
                     receipt->writer == writer &&
                     receipt->mode == mode &&
                     receipt->current == current);
}

typedef struct
{
    uint32_t seq;
    uint32_t tick;
    MotorCmd motorCmd[MotorCount];
    uint32_t seqEpoch;
} LowCmd;

typedef struct
{
    uint32_t tick;
    MotorState motorState[MotorCount];
    MotorApplied motorApplied[MotorCount];
} LowState;

typedef struct
{
    uint32_t seq;
    uint32_t rejected_count;
    uint32_t emergency_stop_count;
    uint32_t inhibit_acquire_count;
    uint32_t inhibit_release_count;
    uint32_t inhibit_mask;
    uint32_t snapshot_retry_count;
    uint32_t snapshot_fallback_count;
    uint32_t last_reject_tick;
    uint16_t last_reject_writer;
    uint16_t last_reject_owner;
    uint16_t emergency_writer;
    uint8_t emergency_active;
    uint8_t reserved0;
    /* 新诊断只能追加，保留既有 Watch 字段偏移。 */
    uint32_t permit_reject_count;
    uint32_t last_permit_reject_mask;
} LowCmdDiag;

static inline MotorId MotorIdRange(MotorId first, uint8_t index, uint8_t count)
{
    if (index >= count || (uint32_t)first >= (uint32_t)MotorCount)
    {
        return MotorCount;
    }
    if (((uint32_t)first + (uint32_t)index) >= (uint32_t)MotorCount)
    {
        return MotorCount;
    }
    return (MotorId)((uint32_t)first + (uint32_t)index);
}

static inline uint8_t MotorModeKnown(uint8_t mode)
{
    return (mode < (uint8_t)MotorModeCount) ? 1u : 0u;
}

void LowCmdClearAll(void);
void LowCmdClear(MotorId id);
uint8_t LowCmdClearManyFrom(const MotorId *ids, uint8_t count, uint16_t writer);
/*
 * 原子清空新获取或升级禁写的命令，并持续阻止更低优先级 writer。
 * 同 writer 重复获取是无副作用成功；更高 writer 可升级 owner；更低 writer 整批失败。
 * 禁写 owner 及更高 writer 仍可写命令，写命令不会自动释放禁写。
 */
uint8_t LowCmdInhibitManyFrom(const MotorId *ids, uint8_t count, uint16_t writer);
/*
 * 同级或更高 writer 可释放；未禁写的电机视为已经释放。
 * 任一电机由更高 writer 禁写时整批不变，释放不改当前命令及命令序号。
 */
uint8_t LowCmdReleaseInhibitManyFrom(const MotorId *ids, uint8_t count, uint16_t writer);
/*
 * 当前控制域凭当帧许可恢复 SAFETY 局部禁写：同一临界区内复核许可、
 * 清掉安全替代命令并释放禁写。NONE 视为已经恢复；其他 owner 整批拒绝。
 */
uint8_t LowCmdRecoverSafetyInhibitWithPermit(MotorId id,
                                              const ControlOutputPermit *permit);
uint8_t LowCmdRecoverSafetyInhibitManyWithPermit(const MotorId *ids,
                                                  uint8_t count,
                                                  const ControlOutputPermit *permit);
uint8_t LowCmdGetInhibitWriter(MotorId id, uint16_t *out);
uint8_t LowCmdGetInhibitWriters(const MotorId *ids, uint16_t *out, uint8_t count);
uint8_t LowCmdSetMotor(MotorId id, const MotorCmd *cmd);
uint8_t LowCmdSetMotorMany(const MotorId *ids, const MotorCmd *cmds, uint8_t count);
/* writer 以 API 参数为准；MotorCmd.writer 是发布后的只读归属信息，不能由载荷提权。 */
uint8_t LowCmdSetMotorFrom(MotorId id, const MotorCmd *cmd, uint16_t writer);
uint8_t LowCmdSetMotorManyFrom(const MotorId *ids, const MotorCmd *cmds, uint8_t count, uint16_t writer);
uint8_t LowCmdSetMotorWithPermit(MotorId id,
                                 const MotorCmd *cmd,
                                 const ControlOutputPermit *permit);
uint8_t LowCmdSetMotorManyWithPermit(const MotorId *ids,
                                     const MotorCmd *cmds,
                                     uint8_t count,
                                     const ControlOutputPermit *permit);
uint8_t LowCmdClearWithPermit(MotorId id, const ControlOutputPermit *permit);
uint8_t LowCmdClearManyWithPermit(const MotorId *ids,
                                  uint8_t count,
                                  const ControlOutputPermit *permit);
const char *MotorModeName(MotorMode mode);
uint32_t LowCmdSeq(void);
uint8_t LowCmdVersionGet(LowCmdVersion *out);
uint8_t LowCmdGet(LowCmd *out);
void LowCmdSetDisable(MotorId id);
void LowCmdSetDisableFrom(MotorId id, uint16_t writer);
void LowCmdSetDamping(MotorId id, fp32 kd, fp32 tau);
void LowCmdSetCurrent(MotorId id, int16_t current);
uint8_t LowCmdSetCurrentMany(const MotorId *ids, const int16_t *currents, uint8_t count);
uint8_t LowCmdSetCurrentManyFrom(const MotorId *ids, const int16_t *currents, uint8_t count, uint16_t writer);
uint8_t LowCmdSetCurrentManyWithPermit(const MotorId *ids,
                                       const int16_t *currents,
                                       uint8_t count,
                                       const ControlOutputPermit *permit);
uint8_t LowCmdSetCurrentWithPermit(MotorId id,
                                   int16_t current,
                                   const ControlOutputPermit *permit);
int16_t LowCmdGetCurrent(MotorId id);
uint8_t LowCmdGetCurrentMany(const MotorId *ids, int16_t *out, uint8_t count);
void LowCmdSetStateTorque(MotorId id, const MotorCmd *cmd);
void LowCmdSetSpeed(MotorId id, fp32 velocity, fp32 kd, fp32 torque);
uint8_t LowCmdGetMotor(MotorId id, MotorCmd *out);
uint8_t LowCmdGetMotorMany(const MotorId *ids, MotorCmd *out, uint8_t count);
uint8_t LowCmdGetMotorStamped(MotorId id,
                              MotorCmd *cmd,
                              ControlOutputStamp *owner);
uint8_t LowCmdGetMotorManyStamped(const MotorId *ids,
                                  MotorCmd *cmds,
                                  ControlOutputStamp *owners,
                                  uint8_t count);
/* 输出数组按 MotorId 索引，供发送层只抓取当前有效路由且保持一次原子快照。 */
uint8_t LowCmdGetMotorManyStampedIndexed(const MotorId *ids,
                                         MotorCmd *cmdsById,
                                         ControlOutputStamp *ownersById,
                                         uint8_t count);
/*
 * 物理发送前的最终授权检查。单向安全的 inactive/None/Disable 可直接发送；
 * 其他活动快照必须仍属于当前发布代和当前控制许可。
 */
uint8_t LowCmdOutputSnapshotAuthorized(MotorId id,
                                       const MotorCmd *cached,
                                       const ControlOutputStamp *cachedOwner);
/* 兼容调试接口：返回快照缓存，新代码优先用 LowCmdGetMotor。 */
const MotorCmd *LowCmdGetMotorPtr(MotorId id);
uint8_t LowCmdEnterEmergencyStop(uint16_t writer);
uint8_t LowCmdClearEmergencyStop(uint16_t writer);
uint8_t LowCmdEmergencyActive(void);
uint8_t LowCmdGetDiag(LowCmdDiag *out);

void LowStateClearAll(void);
void LowStateUpdateMotor(MotorId id, const MotorState *feedback);
void LowStateUpdateApplied(MotorId id, const MotorApplied *applied);
void LowStateUpdateTxQueued(MotorId id, const MotorTxIdentity *identity);
void LowStateUpdateTxComplete(MotorId id, const MotorTxIdentity *identity);
uint8_t LowStateGet(LowState *out);
uint8_t LowStateGetMotor(MotorId id, MotorState *out);
uint8_t LowStateGetMotorMany(const MotorId *ids, MotorState *out, uint8_t count);
/* 兼容调试接口：返回快照缓存，新代码优先用 LowStateGetMotor。 */
const MotorState *LowStateGetMotorPtr(MotorId id);
uint8_t LowStateGetApplied(MotorId id, MotorApplied *out);
/* 兼容调试接口：返回快照缓存，新代码优先用 LowStateGetApplied。 */
const MotorApplied *LowStateGetAppliedPtr(MotorId id);
uint8_t LowStateGetTxReceipt(MotorId id, MotorTxReceipt *out);

#endif
